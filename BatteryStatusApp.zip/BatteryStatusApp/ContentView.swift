import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "battery.100")
                .imageScale(.large)
                .foregroundColor(.green)
            Text("Charging...")
                .padding()
        }
    }
}

#Preview {
    ContentView()
}
