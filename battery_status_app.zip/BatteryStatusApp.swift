import SwiftUI

@main
struct BatteryStatusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
