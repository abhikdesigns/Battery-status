import SwiftUI
import Combine

struct ContentView: View {
    @ObservedObject private var batteryManager = BatteryManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("Battery Level: \(batteryManager.batteryLevel)%")
            Text("Charging: \(batteryManager.isCharging ? "Yes" : "No")")
            if batteryManager.isCharging {
                Text("Estimated time to full charge: \(batteryManager.timeToFullCharge)")
            }
        }
        .padding()
        .onAppear {
            batteryManager.startMonitoring()
        }
    }
}

class BatteryManager: ObservableObject {
    @Published var batteryLevel: Int = 0
    @Published var isCharging: Bool = false
    @Published var timeToFullCharge: String = "Calculating..."

    func startMonitoring() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        updateBatteryInfo()
    }

    private func updateBatteryInfo() {
        batteryLevel = Int(UIDevice.current.batteryLevel * 100)
        isCharging = UIDevice.current.batteryState == .charging || UIDevice.current.batteryState == .full
        if isCharging {
            // Placeholder estimate
            timeToFullCharge = "30 minutes"
        } else {
            timeToFullCharge = "N/A"
        }
    }
}
